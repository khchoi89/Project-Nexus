#!/usr/bin/env python3
"""Gateway local pilot administration. Not internet-facing or production hardened."""
import base64, hashlib, hmac, html, ipaddress, json, os, re, secrets, shutil, ssl, subprocess, tempfile, time
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from threading import Lock

ROOT=Path('/var/lib/homevpn')
WG=Path('/etc/wireguard/wg0.conf')
CONFIG=ROOT/'settings.json'
LOCK=Lock()
SESSIONS={}
PORT=8443
OS_UPDATE_SERVICE='homevpn-os-update.service'
OS_UPDATE_LOG=Path('/var/log/homevpn/os-update.log')
GATEWAY_UPDATE_STATE=Path('/var/lib/gateway/update-status.json')

def shell(args, stdin=None):
    p=subprocess.run(args,input=stdin,text=True,capture_output=True,timeout=20)
    if p.returncode: raise RuntimeError((p.stderr or p.stdout or 'Command failed')[:350])
    return p.stdout.strip()

def readcfg(): return json.loads(CONFIG.read_text())
def savecfg(d):
    temp=CONFIG.with_suffix('.tmp');temp.write_text(json.dumps(d,indent=2));temp.chmod(0o600);temp.replace(CONFIG)
def csrf(): return secrets.token_urlsafe(24)
def hash_pw(pw,salt): return hashlib.pbkdf2_hmac('sha256',pw.encode(),bytes.fromhex(salt),350000).hex()
def get_server_key():
    # Resolve public key from the active configuration (never display private key)
    text=WG.read_text()
    x=re.search(r'(?m)^PrivateKey\s*=\s*(\S+)',text)
    if not x: raise RuntimeError('No server PrivateKey in wg0.conf')
    return shell(['wg','pubkey'],x.group(1)+'\n')
def used_ips():
    result=set()
    for m in re.finditer(r'(?m)^AllowedIPs\s*=\s*(.+)$',WG.read_text()):
        for val in m.group(1).split(','):
            try: result.add(str(ipaddress.ip_interface(val.strip()).ip))
            except ValueError: pass
    return result

def add_peer(name):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _-]{0,39}',name):raise ValueError('Name must be 1–40 letters, digits, spaces, underscores, or dashes.')
    with LOCK:
        cfg=readcfg(); network=ipaddress.ip_network(cfg['subnet'],strict=False)
        taken=used_ips(); existing=cfg.setdefault('devices',[])
        if any(p['name'].casefold()==name.casefold() for p in existing):raise ValueError('Device name already exists.')
        newip=None
        for host in network.hosts():
            if str(host)!=cfg['server_ip'] and str(host) not in taken and all(p['ip']!=str(host) for p in existing):
                newip=str(host); break
        if not newip:raise ValueError('VPN address pool is full.')
        private=shell(['wg','genkey']);public=shell(['wg','pubkey'],private+'\n')
        serverpublic=get_server_key()
        endpoint=cfg['endpoint']
        if not endpoint:raise ValueError('Set a public IP or DNS hostname first.')
        client=f'''[Interface]\nPrivateKey = {private}\nAddress = {newip}/32\nDNS = {cfg['dns']}\n\n[Peer]\nPublicKey = {serverpublic}\nEndpoint = {endpoint}:{cfg['port']}\nAllowedIPs = 0.0.0.0/0\nPersistentKeepalive = 25\n'''
        # Atomic save; existing config backed up before updating.
        old=WG.read_text();stamp=time.strftime('%Y%m%d-%H%M%S')
        shutil.copy2(WG,WG.with_name(f'wg0.conf.backup-{stamp}'))
        addition=f'\n# Gateway device: {name}\n[Peer]\nPublicKey = {public}\nAllowedIPs = {newip}/32\n'
        fd,tmp=tempfile.mkstemp(dir='/etc/wireguard',prefix='.wg0-',text=True)
        try:
            with os.fdopen(fd,'w') as f: f.write(old.rstrip()+'\n'+addition)
            os.chmod(tmp,0o600);os.replace(tmp,WG)
            # reload peers without toggling interface or PostUp/PostDown firewall rules
            stripped=shell(['wg-quick','strip','wg0'])
            shell(['wg','syncconf','wg0','/dev/stdin'],stripped+'\n')
        except Exception:
            WG.write_text(old);WG.chmod(0o600)
            raise
        existing.append({'name':name,'ip':newip,'public_key':public,'created':int(time.time())})
        savecfg(cfg)
        return client

def page(title, body, session=None, notice=''):
    token=session['csrf'] if session else ''
    navbar='<nav><b>Gateway</b></nav>'
    if session:navbar+='<div class="links"><div class="tabs"><a href="/" class="tab'+(' active' if title=='Dashboard' else '')+'">Dashboard</a><p>Gateway v2.2.0-beta.2 - Automatic Update Test Successful</p><a href="/settings" class="tab'+(' active' if title=='Settings' else '')+'">Settings</a></div><form method="post" action="/logout" class="signout"><input type="hidden" name="csrf" value="'+token+'"><button>Sign Out</button></form></div>'
    return ('''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'''+html.escape(title)+''' · Gateway</title><style>
    *{box-sizing:border-box}body{font-family:system-ui,-apple-system,sans-serif;margin:0;background:#f6f8fb;color:#192634}main{max-width:860px;margin:34px auto;padding:0 20px}nav{background:#172c43;color:white;padding:20px max(20px,calc((100vw - 820px)/2))}.links{max-width:860px;margin:18px auto 0;padding:0 20px;display:flex;align-items:center;justify-content:space-between;gap:12px}.tabs{display:flex;gap:8px}.tab{display:inline-block;text-decoration:none;padding:9px 14px;border-radius:7px}.tab.active{background:#d9eaf8;font-weight:700}.signout{margin-left:auto}.signout button{background:#172c43;color:white}a{color:#1160a0}.card{background:white;border:1px solid #dbe1e7;border-radius:13px;padding:23px;margin:16px 0;box-shadow:0 2px 6px #0a22400a}input{width:100%;padding:11px;margin:6px 0 15px;border:1px solid #b9c6d2;border-radius:7px;font:inherit}button{background:#1262a6;color:white;border:0;border-radius:7px;padding:10px 16px;cursor:pointer;font:inherit}.link{background:none;color:#1262a6;padding:0}code,pre{background:#f2f5f8;padding:5px;border-radius:4px;overflow-wrap:anywhere}pre{white-space:pre-wrap;padding:14px}.hint{color:#607388;font-size:.92rem}.warn{color:#904c00}.notice{border-left:4px solid #137db1;background:#eaf4fc;padding:12px;margin:16px 0}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid #e4e9ee;padding:10px;text-align:left}label{font-weight:600}</style></head><body>'''+navbar+'<main><h1>'+html.escape(title)+'</h1>'+(f'<div class="notice">{html.escape(notice)}</div>' if notice else '')+body+'''<p class="hint">Pilot only · Admin interface must remain on your trusted LAN or a separate management VPN. Never port-forward 8443.</p></main></body></html>''')

class Handler(BaseHTTPRequestHandler):
    def log_message(self,fmt,*args): pass
    def send(self,status,body,typ='text/html; charset=utf-8',extra=None):
        self.send_response(status);self.send_header('Content-Type',typ);self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer');self.send_header('Content-Security-Policy',"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
        for k,v in (extra or {}).items():self.send_header(k,v)
        self.end_headers();self.wfile.write(body.encode() if isinstance(body,str) else body)
    def redirect(self,url,extra=None):self.send(303,'',extra={'Location':url,**(extra or {})})
    def session(self):
        c=cookies.SimpleCookie()
        try:c.load(self.headers.get('Cookie',''))
        except Exception:return None
        sid=c.get('hv_session');return SESSIONS.get(sid.value) if sid else None
    def form(self):
        length=int(self.headers.get('Content-Length','0'))
        if length>8192:raise ValueError('Request too large.')
        data=self.rfile.read(length).decode('utf8')
        return {k:v[0] for k,v in parse_qs(data,keep_blank_values=True).items()}
    def csrf_ok(self,s,f):return s and hmac.compare_digest(s['csrf'],f.get('csrf',''))
    def do_GET(self):
        path=urlsplit(self.path).path;s=self.session();cfg=readcfg()
        if not s:
            body='<div class="card"><form method="post" action="/login"><label>Administrator password</label><input type="password" name="password" autocomplete="current-password" required><button>Sign in</button></form></div>'
            return self.send(200,page('Sign in', ('<div class="notice">Password changed. Sign in with your new password.</div>' if parse_qs(urlsplit(self.path).query).get('password_changed')==['1'] else '')+body))
        token=s['csrf']
        if path=='/':
            try: wg=shell(['wg','show','wg0','dump']);lines=wg.splitlines(); peer_lines=lines[1:];active=len(peer_lines); handshakes=sum(1 for line in peer_lines if len(line.split('\t'))>4 and int(line.split('\t')[4] or '0')>time.time()-180)
            except Exception:active=handshakes=0
            rows=''.join('<tr><td>'+html.escape(p['name'])+'</td><td>'+p['ip']+'</td><td>'+html.escape(p['public_key'][:16])+'…</td></tr>' for p in cfg.get('devices',[]))
            body=f'''<div class="card"><h2>Home gateway</h2><p><b>WireGuard peers:</b> {active} · <b>Recent handshakes:</b> {handshakes}</p><p><b>Home endpoint:</b> {html.escape(cfg['endpoint'] or 'Not configured')}:{cfg['port']}</p><p class="hint">Home UDP port forwarding is still required when behind your main router. Existing unmanaged peers are not listed below.</p></div><div class="card"><h2>Add travel router</h2><form method="post" action="/add"><input type="hidden" name="csrf" value="{token}"><label>Device name</label><input name="name" placeholder="My MT3000" maxlength="40" required><button>Generate WireGuard profile</button></form></div><div class="card"><h2>Created devices</h2><table><tr><th>Name</th><th>VPN address</th><th>Public key</th></tr>{rows or '<tr><td colspan="3">No managed devices yet</td></tr>'}</table></div>'''
            return self.send(200,page('Dashboard',body,s))
        if path=='/settings':
            try:
                state=shell(['systemctl','show',OS_UPDATE_SERVICE,'--property=ActiveState','--value'])
                outcome=shell(['systemctl','show',OS_UPDATE_SERVICE,'--property=Result','--value'])
            except Exception:
                state='unknown'; outcome='unknown'
            logtail='\n'.join(OS_UPDATE_LOG.read_text(errors='replace').splitlines()[-18:]) if OS_UPDATE_LOG.exists() else 'No update has run yet.'
            update_card=f'''<div class="card"><h2>System Updates</h2><p>Run Raspberry Pi OS package updates (apt-get update, then apt-get upgrade -y).</p><p><b>State:</b> {html.escape(state)} · <b>Last result:</b> {html.escape(outcome)}</p><form method="post" action="/system-update"><input type="hidden" name="csrf" value="{token}"><button type="submit">Run System Update</button></form><p class="hint">Packages may restart services. Schedule this when VPN users are disconnected. Refresh this page to view progress. A new OS kernel may require a separate reboot.</p><pre>{html.escape(logtail)}</pre></div>'''
            body=f'''<div class="card"><p>These settings apply to <b>new client profiles</b>. They do not change your existing server address, listen port, or firewall.</p><form method="post" action="/settings"><input type="hidden" name="csrf" value="{token}"><label>Public IP or DDNS hostname</label><input name="endpoint" value="{html.escape(cfg['endpoint'])}" required><label>Client DNS resolver</label><input name="dns" value="{html.escape(cfg['dns'])}" required><button>Save settings</button></form><p class="hint">Existing clients must be re-imported if the home endpoint changes.</p></div>'''
            body+=f'''<div class="card"><h2>Change administrator password</h2><form method="post" action="/change-password"><input type="hidden" name="csrf" value="{token}"><label>Current password</label><input name="current_password" type="password" autocomplete="current-password" required><label>New password</label><input name="new_password" type="password" autocomplete="new-password" minlength="12" required><label>Confirm new password</label><input name="confirm_password" type="password" autocomplete="new-password" minlength="12" required><p class="hint">Minimum 12 characters. You will be signed out after changing it.</p><button>Change password</button></form></div>'''
            try:
                update_data=json.loads(GATEWAY_UPDATE_STATE.read_text()) if GATEWAY_UPDATE_STATE.exists() else {'status':'Not checked yet'}
                update_summary=html.escape(json.dumps(update_data,indent=2))
            except Exception: update_summary='Update status unavailable'
            gateway_card=f'''<div class="card"><h2>Gateway Software Updates (Beta)</h2><p>Download only approved, Minisign-verified Gateway releases from Project-Nexus. This updates the Web GUI, not WireGuard.</p><pre>{update_summary}</pre><form method="post" action="/gateway-update-check"><input type="hidden" name="csrf" value="{token}"><button>Check for Updates</button></form><br><form method="post" action="/gateway-update-install"><input type="hidden" name="csrf" value="{token}"><button onclick="return confirm('Install the newest signed Gateway application update? The Web GUI will restart.')">Install Verified Update</button></form><p class="hint">Review available version before installing. Keep TCP 8443 private.</p></div>'''
            return self.send(200,page('Settings',body+update_card+gateway_card,s))
        return self.send(404,page('Not found','',s))
    def do_POST(self):
        s=self.session();path=urlsplit(self.path).path
        try:f=self.form()
        except Exception as e:return self.send(400,page('Invalid request','<p>'+html.escape(str(e))+'</p>',s))
        cfg=readcfg()
        if path=='/login':
            supplied=hash_pw(f.get('password',''),cfg['salt'])
            if not hmac.compare_digest(supplied,cfg['password_hash']):
                time.sleep(.6);return self.send(401,page('Sign in','<div class="notice">Invalid password.</div><a href="/">Try again</a>'))
            sid=secrets.token_urlsafe(32);SESSIONS[sid]={'csrf':csrf()}
            return self.redirect('/',{'Set-Cookie':f'hv_session={sid}; Secure; HttpOnly; SameSite=Strict; Path=/'})
        if not self.csrf_ok(s,f):return self.send(403,'Forbidden')
        if path=='/logout':
            c=cookies.SimpleCookie();c.load(self.headers.get('Cookie',''))
            if 'hv_session' in c:SESSIONS.pop(c['hv_session'].value,None)
            return self.redirect('/',{'Set-Cookie':'hv_session=; Max-Age=0; Secure; HttpOnly; SameSite=Strict; Path=/'})
        if path=='/change-password':
            old=f.get('current_password','');new=f.get('new_password','');confirm=f.get('confirm_password','')
            if not hmac.compare_digest(hash_pw(old,cfg['salt']),cfg['password_hash']):
                time.sleep(.5)
                return self.send(400,page('Password error','<p>Current password is incorrect. <a href="/settings">Try again</a></p>',s))
            if new!=confirm or len(new)<12 or len(new)>256 or new==old:
                return self.send(400,page('Password error','<p>Passwords must match, be 12–256 characters, and differ from the current password. <a href="/settings">Try again</a></p>',s))
            with LOCK:
                latest=readcfg()
                if not hmac.compare_digest(hash_pw(old,latest['salt']),latest['password_hash']):
                    return self.send(409,page('Password error','<p>Password was updated elsewhere. Please sign in again.</p>',s))
                latest['salt']=secrets.token_hex(16)
                latest['password_hash']=hash_pw(new,latest['salt'])
                savecfg(latest)
                SESSIONS.clear()
            return self.redirect('/?password_changed=1',{'Set-Cookie':'hv_session=; Max-Age=0; Secure; HttpOnly; SameSite=Strict; Path=/'})
        if path in ('/gateway-update-check','/gateway-update-install'):
            unit='gateway-update-check.service' if path.endswith('check') else 'gateway-update-install.service'
            try:
                shell(['systemctl','start','--no-block',unit])
                return self.redirect('/settings')
            except Exception as e:
                return self.send(500,page('Update failed to start','<p>'+html.escape(str(e))+'</p>',s))
        if path=='/system-update':
            try:
                state=shell(['systemctl','show',OS_UPDATE_SERVICE,'--property=ActiveState','--value'])
                if state in ('active','activating'):
                    return self.send(409,page('Update already running','<p>System update is already running. <a href="/settings">View status</a></p>',s))
                shell(['systemctl','start','--no-block',OS_UPDATE_SERVICE])
                return self.redirect('/settings')
            except Exception as e:
                return self.send(500,page('Could not start update','<p>'+html.escape(str(e))+'</p>',s))
        if path=='/settings':
            ep=f.get('endpoint','').strip();dns=f.get('dns','').strip()
            if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.-]{0,251}',ep):return self.send(400,page('Settings','<p>Invalid hostname or IPv4 address.</p>',s))
            try:ipaddress.ip_address(dns)
            except ValueError:return self.send(400,page('Settings','<p>DNS must be an IP address.</p>',s))
            cfg['endpoint']=ep;cfg['dns']=dns;savecfg(cfg);return self.redirect('/settings')
        if path=='/add':
            try:profile=add_peer(f.get('name',''))
            except Exception as e:return self.send(400,page('Could not create device','<div class="card"><p>'+html.escape(str(e))+'</p><a href="/">Return to dashboard</a></div>',s))
            filename='homevpn-client.conf'
            return self.send(200,profile,'application/octet-stream',{'Content-Disposition':f'attachment; filename="{filename}"'})
        return self.send(404,'Not found')

def main():
    cfg=readcfg();print('Gateway on HTTPS port',PORT,flush=True)
    server=ThreadingHTTPServer(('0.0.0.0',PORT),Handler)
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version=ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain('/etc/homevpn/localhost.crt','/etc/homevpn/localhost.key')
    server.socket=ctx.wrap_socket(server.socket,server_side=True)
    server.serve_forever()
if __name__=='__main__':main()
